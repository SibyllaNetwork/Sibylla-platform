// Tipi pubblici di @sibylla-hr/hr-pages per chi usa la build compilata (sibylla-platform, TypeScript 4.9).
// Scritti a mano e compatibili con TS 4.x: aggiornali quando cambia src/index.ts.
import type { ReactElement, ReactNode } from 'react'

export type HrRole = 'Employee' | 'Manager' | 'Hr'

export interface IssuedToken { accessToken: string; expiresAt: string }

export interface Me {
  user: { id: string; email: string; name: string; role: HrRole }
  tenant: { id: string; slug: string; name: string }
  authSource: 'local' | 'platform'
}

export interface TenantModules { leave: boolean; attendance: boolean; expenses: boolean; payslips: boolean; social: boolean }

export interface TenantSettings { modules: TenantModules; hrRules: Record<string, unknown> }

export interface HrApiConfig {
  baseUrl: string
  getToken?: () => string | null
  getTenantSlug?: () => string | null
  onUnauthorized?: () => void
}

export declare class HrApiError extends Error {
  readonly status: number
  readonly code: string
  readonly fieldErrors: Record<string, string[]>
  readonly detail?: string
}

export interface HrApi {
  me(): Promise<Me>
  settings(): Promise<TenantSettings>
  [endpoint: string]: unknown
}

export declare function createHrApi(config: HrApiConfig): HrApi
export declare function HrApiProvider(props: { api: HrApi; children?: ReactNode }): ReactElement
export declare function errorMessage(err: unknown): string

export declare const ROLE_LABELS: Record<HrRole, string>
export declare const MODULE_LABELS: Record<keyof TenantModules, string>

export declare function HomePage(props: { me: Me; modules?: TenantModules; pushWorkerUrl?: string; onNavigate?: (to: string) => void }): ReactElement
export declare function EmployeesPage(props: { integrated?: boolean }): ReactElement
export declare function DepartmentsPage(): ReactElement
export declare function ImportEmployeesPage(): ReactElement

// Ferie e permessi
export declare function MyLeavePage(): ReactElement
export declare function ApprovalsPage(): ReactElement
export declare function TeamLeavePage(props: { isHr: boolean }): ReactElement
export declare function BalancesPage(): ReactElement
export declare function TeamCalendarPage(props: { isHr: boolean }): ReactElement
export declare function VacationPlansPage(props: { isHr: boolean; onOpen: (id: string) => void }): ReactElement
export declare function VacationPlanPage(props: { id: string; isHr: boolean; onBack: () => void }): ReactElement

// Presenze
export declare function MyAttendancePage(): ReactElement
export declare function TodayPage(props: { isHr: boolean }): ReactElement
export declare function AttendanceHrPage(): ReactElement

// Note spese, cedolini e documenti
export declare function ExpensesPage(props: { isHr: boolean }): ReactElement
export declare function MyDocumentsPage(): ReactElement
export declare function PayslipsHrPage(): ReactElement
export declare function CompanyDocumentsPage(): ReactElement

// Chat, news, comunicazioni e rubrica
export declare function ChatPage(props: { isHr: boolean }): ReactElement
export declare function NewsPage(props: { isHr: boolean }): ReactElement
export declare function MyCommunicationsPage(): ReactElement
export declare function CommunicationsHrPage(): ReactElement
export declare function DirectoryPage(props: { isHr: boolean }): ReactElement

// Report
export declare function ReportsPage(props: { isHr: boolean }): ReactElement
export declare function AuditPage(): ReactElement
