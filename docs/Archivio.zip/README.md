# Documentazione Sibylla Platform

Indice della documentazione per sviluppatori.

## In questa cartella (`docs/`)

- **[integrazioni-backend.md](./integrazioni-backend.md)**: **indice per gli sviluppatori del backend (Portal)**. Tutti
  i documenti di integrazione di Platform e di Op, in che ordine leggerli, cosa sblocca ognuno e cosa sistemare prima
  del rilascio.
- **[portal-magazzino-ristorazione.md](./portal-magazzino-ristorazione.md)**: Magazzino della Ristorazione nel database
  di Sibylla. Scheda completa per il Portal: azioni, modello dati, configurazione e rilascio, script SQL, contratto.
- **[guida-sviluppatori.md](./guida-sviluppatori.md)** — punto d'ingresso operativo:
  come installare, avviare e riprodurre da zero front-end e back-end (prerequisiti,
  env, comandi, auth, service layer, smoke test, troubleshooting).
- **[layout-responsive.md](./layout-responsive.md)** — regole di layout responsive
  e dinamiche di apertura/chiusura del sidenav (budget larghezza laptop, tabelle).
- **[copy-editabile-multilingua.md](./copy-editabile-multilingua.md)** — sistema di
  copy editabile dall'assistenza e pubblicabile in multilingua (JSON nel repo,
  per-cliente, editor nel clone, traduzione in build).
- **[nuova-prenotazione.md](./nuova-prenotazione.md)** — specifica funzionale/tecnica
  della pagina Nuova prenotazione per il porting/cablaggio al backend.
- **[bi.md](./bi.md)** — sezione Business Intelligence: kit condiviso `core/bi`
  (impianto a schermo fisso senza scroll, palette grafici, legenda acronimi) e piano
  dei contenuti pagina per pagina con le metriche di settore.
- **[food-beverage.md](./food-beverage.md)** — briefing di consegna della sezione Food &
  Beverage (Outlet Manager): stato dell'integrazione, back-end Flask separato, debito
  noto, decisioni aperte e roadmap per chi prende in carico lo sviluppo.
- **[skills/sibylla-ui-migration/SKILL.md](./skills/sibylla-ui-migration/SKILL.md)** —
  skill caricabile da un agente AI: linee guida e caratteristiche per migrare le
  pagine Sibylla su un'altra piattaforma mantenendo inalterata la UI/UX.

## Documenti autorevoli in root

- **[../ARCHITECTURE.md](../ARCHITECTURE.md)** — architettura del front-end: design
  system, moduli funzionali, temi runtime, routing, metriche.
- **[../INTEGRATION.md](../INTEGRATION.md)** — contratto e integrazione FE ↔ BE:
  proxy edge, autenticazione, elenco service ed endpoint, pagine cablate.
- **[../SIBYLLA_BRIEFING.md](../SIBYLLA_BRIEFING.md)** — briefing di prodotto/contesto.
- **[../README.md](../README.md)** — note Create React App.

## Percorso consigliato

1. Leggi **guida-sviluppatori.md** e avvia FE + BE.
2. Approfondisci con **ARCHITECTURE.md** (front) e **INTEGRATION.md** (integrazione).
3. Consulta **layout-responsive.md** quando lavori su layout/tabelle.
